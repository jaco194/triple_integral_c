# Overview

This is a scientific computing project that calculates the total mass and center of mass of three-dimensional bodies with variable density using numerical triple integration methods. The program implements two integration approaches: Riemann 3D (deterministic subdivision) and Monte Carlo (stochastic sampling). It's designed for educational purposes to demonstrate numerical integration techniques in C.

**Recent Update (Nov 18, 2025)**: Added dedicated `resultados/` directory for CSV output files to keep data organized separately from source code.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Code Organization

The project follows a modular C architecture with clear separation of concerns:

**Module Structure:**
- **Density Functions Module** (`densidades.c/h`): Encapsulates mathematical density functions as pluggable components. This design allows easy addition of new density functions without modifying integration code.
- **Integration Methods Module** (`integracion.c/h`): Implements numerical integration algorithms independently of density functions. Uses function pointers to accept any density function, enabling flexible composition.
- **Main Program** (`main.c`): Orchestrates calculations by combining density functions with integration methods.

**Rationale:** This separation follows the single responsibility principle - each module has one clear purpose. It makes testing easier (each algorithm can be verified independently) and allows reusing integration methods with different density functions.

## Build System

Uses Make for compilation automation. This choice addresses:
- **Problem:** Managing compilation dependencies across multiple source files
- **Solution:** Makefile with automatic dependency tracking
- **Alternative Considered:** Manual compilation with shell scripts
- **Pros:** Incremental compilation (only recompiles changed files), standard tool familiar to C developers
- **Cons:** Make syntax can be cryptic for beginners

## Numerical Methods

**Riemann 3D Integration:**
- Divides the 3D region into a regular grid (Nx × Ny × Nz subcells)
- Evaluates density at the center of each subcell
- Sums weighted contributions

**Monte Carlo Integration:**
- Generates random sample points within the integration domain
- Averages density values across samples
- Uses statistical sampling to approximate the integral

**Rationale:** Providing both methods demonstrates the trade-off between deterministic accuracy (Riemann) and computational efficiency for complex regions (Monte Carlo). Riemann gives predictable convergence; Monte Carlo handles irregular boundaries better and scales better with dimensionality.

## Mathematical Functions

Implements three density functions with different characteristics:
1. **Constant Density** (ρ = 1): Baseline case for verification
2. **Linear Density** (ρ = ax + by + cz): Tests gradient handling
3. **Gaussian Density** (ρ = exp(-(x² + y² + z²))): Tests exponential decay

**Design Choice:** Functions are pure (no side effects) and use standard double precision. Parameters (a, b, c for linear density) are hardcoded as constants rather than runtime arguments to keep the interface simple while still demonstrating the concept.

## Data Flow

1. Main program defines integration bounds and resolution parameters
2. Calls integration function with selected density function pointer
3. Integration method iterates over domain, calling density function
4. Results (mass, center of mass coordinates) returned to main
5. Main program displays formatted results
6. Results are saved to CSV file in `resultados/` directory

## Header Guards

All header files use include guards to prevent multiple inclusion problems. This is critical in C to avoid duplicate definitions during compilation when headers are included from multiple sources.

# External Dependencies

## Standard C Library

- **`<stdio.h>`**: Input/output operations for displaying results
- **`<math.h>`**: Mathematical functions (exp, sqrt) for density calculations
- **`<stdlib.h>`**: Memory allocation (if needed for dynamic arrays) and random number generation (rand, srand for Monte Carlo)
- **`<time.h>`**: Seeding random number generator with current time

## Compiler Requirements

- **GCC or compatible C compiler**: Required for compilation
- **C99 standard or later**: Needed for double precision math and standard features

## No External Libraries

The project intentionally uses only standard C library functions, avoiding external dependencies. This makes it:
- Highly portable across systems
- Easy to compile and run
- Suitable for educational environments
- Free from dependency management complexity

**Rationale:** For a scientific computing educational project, minimizing dependencies allows focus on the algorithms rather than library management. The calculations don't require optimized linear algebra libraries that would be needed for production scientific code.