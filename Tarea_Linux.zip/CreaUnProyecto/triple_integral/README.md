# Cálculo de Masa y Centro de Masa 3D
## Mediante Integración Triple Numérica

---

## 📋 Objetivo del Proyecto

Este proyecto implementa un programa en lenguaje C que calcula:

- **Masa total** de un cuerpo tridimensional
- **Centro de masa** (x̄, ȳ, z̄)

Para cuerpos con **densidad variable** utilizando métodos de **integración triple numérica**:

1. **Método de Riemann 3D** - Aproximación determinística mediante subdivisión regular
2. **Método Monte Carlo** - Aproximación estocástica mediante muestreo aleatorio

---

## 📁 Estructura del Código

```
triple_integral/
│
├── src/                      # Archivos fuente (.c)
│   ├── main.c               # Programa principal
│   ├── integracion.c        # Implementación de métodos de integración
│   └── densidades.c         # Implementación de funciones de densidad
│
├── include/                  # Archivos de encabezado (.h)
│   ├── integracion.h        # Declaraciones de funciones de integración
│   └── densidades.h         # Declaraciones de funciones de densidad
│
├── Makefile                  # Script de compilación
└── README.md                 # Este archivo
```

### Descripción de Módulos

#### `densidades.c / densidades.h`
Implementa tres funciones de densidad:

1. **Densidad Constante**: ρ(x,y,z) = 1
2. **Densidad Lineal**: ρ(x,y,z) = ax + by + cz
3. **Densidad Gaussiana**: ρ(x,y,z) = exp(-(x² + y² + z²))

#### `integracion.c / integracion.h`
Implementa dos métodos de integración numérica:

1. **Riemann 3D**: Divide la región en Nx × Ny × Nz subceldas y evalúa en el centro
2. **Monte Carlo**: Genera N puntos aleatorios y calcula el promedio

#### `main.c`
Programa principal que:
- Solicita parámetros al usuario
- Calcula la masa: M = ∭ ρ(x,y,z) dV
- Calcula el centro de masa:
  - x̄ = (1/M) ∭ x·ρ(x,y,z) dV
  - ȳ = (1/M) ∭ y·ρ(x,y,z) dV
  - z̄ = (1/M) ∭ z·ρ(x,y,z) dV
- Mide el tiempo de ejecución
- Guarda resultados en archivo CSV

---

## 🔧 Cómo Compilar

### Requisitos
- Compilador GCC
- Make (sistema de construcción)
- Sistema Linux/Unix o compatible

### Compilación

En el directorio `triple_integral/`, ejecutar:

```bash
make
```

Esto compilará todos los archivos fuente y creará el ejecutable `triple_integral`.

### Limpiar archivos compilados

Para eliminar archivos objeto y el ejecutable:

```bash
make clean
```

---

## ▶️ Cómo Ejecutar

### Ejecución básica

```bash
./triple_integral
```

El programa solicitará interactivamente:

1. **Método de integración**:
   - 1 = Riemann 3D
   - 2 = Monte Carlo

2. **Tipo de densidad**:
   - 1 = Constante
   - 2 = Lineal
   - 3 = Gaussiana

3. **Límites de integración**:
   - x mínimo, x máximo
   - y mínimo, y máximo
   - z mínimo, z máximo

4. **Parámetros del método**:
   - Para Riemann: Nx, Ny, Nz (número de subdivisiones)
   - Para Monte Carlo: N (número de muestras)

---

## 📊 Ejemplos de Uso

### Ejemplo 1: Densidad Constante con Riemann

```
Seleccione el metodo de integracion:
  1 - Riemann 3D
  2 - Monte Carlo
Opcion: 1

Seleccione el tipo de densidad:
  1 - Constante: rho(x,y,z) = 1
  2 - Lineal: rho(x,y,z) = x + y + z
  3 - Gaussiana: rho(x,y,z) = exp(-(x^2 + y^2 + z^2))
Opcion: 1

Ingrese los limites de integracion:
x minimo: 0
x maximo: 1
y minimo: 0
y maximo: 1
z minimo: 0
z maximo: 1

Numero de subdivisiones en x (Nx): 50
Numero de subdivisiones en y (Ny): 50
Numero de subdivisiones en z (Nz): 50
```

**Resultado esperado**:
- Masa ≈ 1.0 (volumen del cubo unitario)
- Centro de masa ≈ (0.5, 0.5, 0.5) (centro del cubo)

### Ejemplo 2: Densidad Gaussiana con Monte Carlo

```
Opcion: 2

Opcion: 3

Ingrese los limites de integracion:
x minimo: -2
x maximo: 2
y minimo: -2
y maximo: 2
z minimo: -2
z maximo: 2

Numero de muestras aleatorias (N): 1000000
```

**Resultado esperado**:
- Masa ≈ 5.568 (integral de Gaussiana 3D)
- Centro de masa ≈ (0, 0, 0) (centrado en el origen por simetría)

### Ejemplo 3: Densidad Lineal con Riemann

```
Opcion: 1

Opcion: 2

Ingrese los limites de integracion:
x minimo: 0
x maximo: 1
y minimo: 0
y maximo: 1
z minimo: 0
z maximo: 1

Numero de subdivisiones en x (Nx): 100
Numero de subdivisiones en y (Ny): 100
Numero de subdivisiones en z (Nz): 100
```

**Resultado esperado**:
- Masa ≈ 1.5
- Centro de masa desplazado hacia valores positivos

---

## 📈 Salida del Programa

### Salida en pantalla

El programa muestra:
- Parámetros ingresados
- Resultados del cálculo:
  - Masa total (M)
  - Coordenadas del centro de masa (x̄, ȳ, z̄)
  - Tiempo de ejecución

### Archivo CSV

Los resultados se guardan automáticamente en `resultados/resultados.csv` con el formato:

```
Metodo,Densidad,Nx,Ny,Nz,N,M,x_bar,y_bar,z_bar,Tiempo
```

Ejemplo de contenido:
```
Metodo,Densidad,Nx,Ny,Nz,N,M,x_bar,y_bar,z_bar,Tiempo
Riemann,Constante,50,50,50,0,1,0.5,0.5,0.5,0.234567
MonteCarlo,Gaussiana,0,0,0,1000000,5.568,0.001,-0.002,0.003,1.456789
```

---

## 🔬 Fundamento Matemático

### Masa Total

La masa se calcula integrando la densidad sobre todo el volumen:

```
M = ∭ ρ(x,y,z) dV
```

### Centro de Masa

Las coordenadas del centro de masa se calculan como:

```
x̄ = (1/M) ∭ x·ρ(x,y,z) dV
ȳ = (1/M) ∭ y·ρ(x,y,z) dV
z̄ = (1/M) ∭ z·ρ(x,y,z) dV
```

### Métodos Numéricos

#### Riemann 3D
- Subdivide la región en Nx × Ny × Nz celdas
- Evalúa la función en el centro de cada celda
- Complejidad: O(Nx·Ny·Nz)
- Convergencia: Error proporcional a (1/N)²

#### Monte Carlo
- Genera N puntos aleatorios uniformes
- Promedia los valores de la función
- Complejidad: O(N)
- Convergencia: Error proporcional a 1/√N

---

## ⚙️ Consideraciones Técnicas

- **Compilador**: Compatible con GCC y estándares C99/C11
- **Librerías**: Solo librerías estándar de C (stdio, stdlib, math, time)
- **Advertencias**: Código compilado sin warnings usando `-Wall -Wextra`
- **Precisión**: Double precision (IEEE 754)
- **Portabilidad**: Compatible con sistemas UNIX/Linux

---

## 📝 Notas

1. **Convergencia del Método de Riemann**: 
   - Aumentar Nx, Ny, Nz mejora la precisión pero incrementa el tiempo cúbicamente

2. **Convergencia de Monte Carlo**:
   - La precisión mejora con √N
   - Más eficiente para regiones de alta dimensión
   - Los resultados varían entre ejecuciones (naturaleza estocástica)

3. **Validación de Densidades**:
   - Densidad lineal puede ser negativa en algunas regiones
   - El programa verifica que la masa total sea positiva

4. **Rendimiento**:
   - El tiempo de ejecución se mide y guarda en el CSV
   - Útil para comparar eficiencia de métodos

---

## 👥 Autor

Proyecto desarrollado como ejemplo de integración numérica en C.

---

## 📄 Licencia

Este código es de dominio público y puede ser usado libremente con fines educativos.
