/*
 * densidades.h
 * 
 * Header file for density functions used in triple integration.
 * 
 * This file defines three different density functions that can be used
 * to model the density distribution of a 3D body:
 * - Constant density
 * - Linear density
 * - Gaussian density
 * 
 * Each function takes 3D coordinates (x, y, z) and returns the density
 * at that point.
 */

#ifndef DENSIDADES_H
#define DENSIDADES_H

/*
 * densidad_constante
 * 
 * Calculates constant density throughout the body.
 * 
 * Function: ρ(x,y,z) = 1
 * 
 * Parameters:
 *   x - X coordinate
 *   y - Y coordinate
 *   z - Z coordinate
 * 
 * Returns:
 *   Constant density value of 1.0
 */
double densidad_constante(double x, double y, double z);

/*
 * densidad_lineal
 * 
 * Calculates linear density varying with position.
 * 
 * Function: ρ(x,y,z) = a*x + b*y + c*z
 * 
 * Parameters:
 *   x - X coordinate
 *   y - Y coordinate
 *   z - Z coordinate
 * 
 * Returns:
 *   Linear density based on position
 * 
 * Note: Coefficients a, b, c are defined as constants within the implementation
 */
double densidad_lineal(double x, double y, double z);

/*
 * densidad_gauss
 * 
 * Calculates Gaussian (normal) density distribution centered at origin.
 * 
 * Function: ρ(x,y,z) = exp(-(x² + y² + z²))
 * 
 * This creates a bell-shaped density distribution that decreases
 * exponentially with distance from the origin.
 * 
 * Parameters:
 *   x - X coordinate
 *   y - Y coordinate
 *   z - Z coordinate
 * 
 * Returns:
 *   Gaussian density value
 */
double densidad_gauss(double x, double y, double z);

#endif /* DENSIDADES_H */
