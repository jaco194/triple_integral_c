/*
 * integracion.h
 * 
 * Header file for numerical triple integration methods.
 * 
 * This file provides two numerical integration methods for calculating
 * triple integrals over rectangular regions:
 * - Riemann 3D: Deterministic method using regular grid subdivision
 * - Monte Carlo: Stochastic method using random sampling
 * 
 * Both methods can integrate any function f(x,y,z) over a rectangular
 * region defined by [xmin,xmax] × [ymin,ymax] × [zmin,zmax].
 */

#ifndef INTEGRACION_H
#define INTEGRACION_H

/*
 * integrar_riemann
 * 
 * Computes triple integral using the Riemann sum method in 3D.
 * 
 * Method:
 * - Divides the integration region into Nx × Ny × Nz subcells
 * - Evaluates the function at the center of each subcell
 * - Sums all values weighted by subcell volume
 * 
 * Formula: I ≈ Σ f(xc, yc, zc) * dV
 * where dV = dx * dy * dz
 * 
 * Parameters:
 *   f    - Pointer to function to integrate f(x,y,z)
 *   xmin - Lower bound for x
 *   xmax - Upper bound for x
 *   ymin - Lower bound for y
 *   ymax - Upper bound for y
 *   zmin - Lower bound for z
 *   zmax - Upper bound for z
 *   Nx   - Number of subdivisions in x direction
 *   Ny   - Number of subdivisions in y direction
 *   Nz   - Number of subdivisions in z direction
 * 
 * Returns:
 *   Approximation of the triple integral
 * 
 * Note: Accuracy increases with Nx, Ny, Nz but computation time
 *       increases as O(Nx * Ny * Nz)
 */
double integrar_riemann(
    double (*f)(double, double, double),
    double xmin, double xmax,
    double ymin, double ymax,
    double zmin, double zmax,
    int Nx, int Ny, int Nz
);

/*
 * integrar_montecarlo
 * 
 * Computes triple integral using the Monte Carlo method.
 * 
 * Method:
 * - Generates N random points uniformly distributed in the region
 * - Evaluates the function at each random point
 * - Computes the average and scales by the volume
 * 
 * Formula: I ≈ V * (1/N) * Σ f(xi, yi, zi)
 * where V = (xmax-xmin) * (ymax-ymin) * (zmax-zmin)
 * 
 * Parameters:
 *   f    - Pointer to function to integrate f(x,y,z)
 *   xmin - Lower bound for x
 *   xmax - Upper bound for x
 *   ymin - Lower bound for y
 *   ymax - Upper bound for y
 *   zmin - Lower bound for z
 *   zmax - Upper bound for z
 *   N    - Number of random sample points
 * 
 * Returns:
 *   Approximation of the triple integral
 * 
 * Note: - Uses rand() for random number generation
 *       - Random seed should be set before calling (srand)
 *       - Accuracy increases with √N, slower than Riemann but
 *         more efficient for high-dimensional integrals
 */
double integrar_montecarlo(
    double (*f)(double, double, double),
    double xmin, double xmax,
    double ymin, double ymax,
    double zmin, double zmax,
    int N
);

#endif /* INTEGRACION_H */
