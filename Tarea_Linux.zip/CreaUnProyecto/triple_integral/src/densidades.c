/*
 * densidades.c
 * 
 * Implementation of density functions for triple integration.
 * 
 * This file implements three different density distribution models
 * that can be used to calculate mass and center of mass of 3D bodies.
 */

#include <math.h>
#include "../include/densidades.h"

/* Coefficients for linear density function */
#define COEF_A 1.0
#define COEF_B 1.0
#define COEF_C 1.0

/*
 * densidad_constante
 * 
 * Implementation of constant density function.
 * Returns 1.0 for all points in space, representing a uniform
 * density distribution.
 */
double densidad_constante(double x, double y, double z) {
    /* Avoid unused parameter warnings */
    (void)x;
    (void)y;
    (void)z;
    
    /* Constant density of 1.0 throughout the body */
    return 1.0;
}

/*
 * densidad_lineal
 * 
 * Implementation of linear density function.
 * 
 * The density varies linearly with position according to:
 * ρ(x,y,z) = a*x + b*y + c*z
 * 
 * This models a body whose density increases or decreases
 * linearly in each spatial direction.
 */
double densidad_lineal(double x, double y, double z) {
    /* Linear combination of coordinates */
    return COEF_A * x + COEF_B * y + COEF_C * z;
}

/*
 * densidad_gauss
 * 
 * Implementation of Gaussian (normal) density function.
 * 
 * The density follows a 3D Gaussian distribution:
 * ρ(x,y,z) = exp(-(x² + y² + z²))
 * 
 * This creates a bell-shaped density distribution centered at
 * the origin, with density decreasing exponentially with distance.
 * Useful for modeling bodies with concentrated mass at the center.
 */
double densidad_gauss(double x, double y, double z) {
    /* Calculate squared distance from origin */
    double r_squared = x*x + y*y + z*z;
    
    /* Return Gaussian density */
    return exp(-r_squared);
}
