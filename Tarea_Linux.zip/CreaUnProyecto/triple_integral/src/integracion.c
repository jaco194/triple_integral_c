/*
 * integracion.c
 * 
 * Implementation of numerical triple integration methods.
 * 
 * This file provides two methods for approximating triple integrals:
 * 1. Riemann 3D: Uses regular grid subdivision
 * 2. Monte Carlo: Uses random sampling
 */

#include <stdlib.h>
#include "../include/integracion.h"

/*
 * integrar_riemann
 * 
 * Implements the 3D Riemann sum method for triple integration.
 * 
 * Algorithm:
 * 1. Calculate step sizes: dx, dy, dz
 * 2. Calculate volume element: dV = dx * dy * dz
 * 3. For each subcell (i, j, k):
 *    - Calculate center point (xc, yc, zc)
 *    - Evaluate function at center: f(xc, yc, zc)
 *    - Add contribution to sum
 * 4. Result = sum * dV
 */
double integrar_riemann(
    double (*f)(double, double, double),
    double xmin, double xmax,
    double ymin, double ymax,
    double zmin, double zmax,
    int Nx, int Ny, int Nz
) {
    double suma = 0.0;
    
    /* Calculate step sizes for each dimension */
    double dx = (xmax - xmin) / Nx;
    double dy = (ymax - ymin) / Ny;
    double dz = (zmax - zmin) / Nz;
    
    /* Calculate volume of each subcell */
    double dV = dx * dy * dz;
    
    /* Triple loop over all subcells */
    for (int i = 0; i < Nx; i++) {
        /* Calculate x coordinate at center of subcell */
        double xc = xmin + (i + 0.5) * dx;
        
        for (int j = 0; j < Ny; j++) {
            /* Calculate y coordinate at center of subcell */
            double yc = ymin + (j + 0.5) * dy;
            
            for (int k = 0; k < Nz; k++) {
                /* Calculate z coordinate at center of subcell */
                double zc = zmin + (k + 0.5) * dz;
                
                /* Evaluate function at center and add to sum */
                suma += f(xc, yc, zc);
            }
        }
    }
    
    /* Multiply sum by volume element to get integral approximation */
    return suma * dV;
}

/*
 * integrar_montecarlo
 * 
 * Implements the Monte Carlo method for triple integration.
 * 
 * Algorithm:
 * 1. Calculate total volume of integration region
 * 2. Generate N random points uniformly in the region
 * 3. Evaluate function at each random point
 * 4. Calculate average value of function
 * 5. Result = volume * average
 * 
 * Note: This function uses rand() for random number generation.
 *       The caller should set the random seed using srand() before
 *       calling this function if reproducible results are needed.
 */
double integrar_montecarlo(
    double (*f)(double, double, double),
    double xmin, double xmax,
    double ymin, double ymax,
    double zmin, double zmax,
    int N
) {
    double suma = 0.0;
    
    /* Calculate dimensions of integration region */
    double dx = xmax - xmin;
    double dy = ymax - ymin;
    double dz = zmax - zmin;
    
    /* Calculate total volume of region */
    double volumen = dx * dy * dz;
    
    /* Generate N random points and evaluate function */
    for (int i = 0; i < N; i++) {
        /* Generate random coordinates uniformly in [0,1] */
        double rx = (double)rand() / RAND_MAX;
        double ry = (double)rand() / RAND_MAX;
        double rz = (double)rand() / RAND_MAX;
        
        /* Scale random coordinates to integration region */
        double x = xmin + rx * dx;
        double y = ymin + ry * dy;
        double z = zmin + rz * dz;
        
        /* Evaluate function at random point and add to sum */
        suma += f(x, y, z);
    }
    
    /* Calculate average and scale by volume */
    double promedio = suma / N;
    
    return volumen * promedio;
}
