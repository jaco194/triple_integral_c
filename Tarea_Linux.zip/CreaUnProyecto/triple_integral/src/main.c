/*
 * main.c
 * 
 * Main program for calculating mass and center of mass of 3D bodies
 * using triple numerical integration.
 * 
 * This program allows the user to:
 * - Select integration method (Riemann or Monte Carlo)
 * - Choose density function (constant, linear, or Gaussian)
 * - Define integration region
 * - Calculate total mass and center of mass
 * - Save results to CSV file with timing information
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "../include/integracion.h"
#include "../include/densidades.h"

/* Function pointer type for density functions */
typedef double (*DensityFunc)(double, double, double);

/* Helper function to create weighted density function for x-coordinate */
double f_x_rho(double x, double y, double z);

/* Helper function to create weighted density function for y-coordinate */
double f_y_rho(double x, double y, double z);

/* Helper function to create weighted density function for z-coordinate */
double f_z_rho(double x, double y, double z);

/* Global pointer to current density function (used by helper functions) */
DensityFunc densidad_actual = NULL;

/*
 * Helper function: x * ρ(x,y,z)
 * Used for calculating x-component of center of mass
 */
double f_x_rho(double x, double y, double z) {
    return x * densidad_actual(x, y, z);
}

/*
 * Helper function: y * ρ(x,y,z)
 * Used for calculating y-component of center of mass
 */
double f_y_rho(double x, double y, double z) {
    return y * densidad_actual(x, y, z);
}

/*
 * Helper function: z * ρ(x,y,z)
 * Used for calculating z-component of center of mass
 */
double f_z_rho(double x, double y, double z) {
    return z * densidad_actual(x, y, z);
}

/*
 * Main function
 * 
 * Workflow:
 * 1. Get user input for method, density, and parameters
 * 2. Calculate mass M = ∭ ρ(x,y,z) dV
 * 3. Calculate center of mass coordinates:
 *    x̄ = (1/M) ∭ x*ρ(x,y,z) dV
 *    ȳ = (1/M) ∭ y*ρ(x,y,z) dV
 *    z̄ = (1/M) ∭ z*ρ(x,y,z) dV
 * 4. Save results to CSV file
 */
int main(void) {
    int metodo, tipo_densidad;
    double xmin, xmax, ymin, ymax, zmin, zmax;
    int Nx = 0, Ny = 0, Nz = 0, N = 0;
    double masa, x_bar, y_bar, z_bar;
    clock_t start, end;
    double tiempo;
    
    printf("=================================================\n");
    printf("   CALCULO DE MASA Y CENTRO DE MASA 3D\n");
    printf("   Mediante Integracion Triple Numerica\n");
    printf("=================================================\n\n");
    
    /* ===== USER INPUT ===== */
    
    /* Select integration method */
    printf("Seleccione el metodo de integracion:\n");
    printf("  1 - Riemann 3D\n");
    printf("  2 - Monte Carlo\n");
    printf("Opcion: ");
    if (scanf("%d", &metodo) != 1 || (metodo != 1 && metodo != 2)) {
        fprintf(stderr, "Error: Opcion invalida\n");
        return 1;
    }
    
    /* Select density function */
    printf("\nSeleccione el tipo de densidad:\n");
    printf("  1 - Constante: rho(x,y,z) = 1\n");
    printf("  2 - Lineal: rho(x,y,z) = x + y + z\n");
    printf("  3 - Gaussiana: rho(x,y,z) = exp(-(x^2 + y^2 + z^2))\n");
    printf("Opcion: ");
    if (scanf("%d", &tipo_densidad) != 1 || tipo_densidad < 1 || tipo_densidad > 3) {
        fprintf(stderr, "Error: Opcion invalida\n");
        return 1;
    }
    
    /* Set density function pointer based on selection */
    switch(tipo_densidad) {
        case 1:
            densidad_actual = densidad_constante;
            break;
        case 2:
            densidad_actual = densidad_lineal;
            break;
        case 3:
            densidad_actual = densidad_gauss;
            break;
    }
    
    /* Get integration limits */
    printf("\nIngrese los limites de integracion:\n");
    printf("x minimo: ");
    if (scanf("%lf", &xmin) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    printf("x maximo: ");
    if (scanf("%lf", &xmax) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    printf("y minimo: ");
    if (scanf("%lf", &ymin) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    printf("y maximo: ");
    if (scanf("%lf", &ymax) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    printf("z minimo: ");
    if (scanf("%lf", &zmin) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    printf("z maximo: ");
    if (scanf("%lf", &zmax) != 1) {
        fprintf(stderr, "Error: Valor invalido\n");
        return 1;
    }
    
    /* Validate integration bounds */
    if (xmax <= xmin) {
        fprintf(stderr, "Error: x maximo debe ser mayor que x minimo\n");
        return 1;
    }
    if (ymax <= ymin) {
        fprintf(stderr, "Error: y maximo debe ser mayor que y minimo\n");
        return 1;
    }
    if (zmax <= zmin) {
        fprintf(stderr, "Error: z maximo debe ser mayor que z minimo\n");
        return 1;
    }
    
    /* Get method-specific parameters */
    if (metodo == 1) {
        /* Riemann method: get number of subdivisions */
        printf("\nNumero de subdivisiones en x (Nx): ");
        if (scanf("%d", &Nx) != 1 || Nx <= 0) {
            fprintf(stderr, "Error: Valor invalido\n");
            return 1;
        }
        printf("Numero de subdivisiones en y (Ny): ");
        if (scanf("%d", &Ny) != 1 || Ny <= 0) {
            fprintf(stderr, "Error: Valor invalido\n");
            return 1;
        }
        printf("Numero de subdivisiones en z (Nz): ");
        if (scanf("%d", &Nz) != 1 || Nz <= 0) {
            fprintf(stderr, "Error: Valor invalido\n");
            return 1;
        }
    } else {
        /* Monte Carlo method: get number of samples */
        printf("\nNumero de muestras aleatorias (N): ");
        if (scanf("%d", &N) != 1 || N <= 0) {
            fprintf(stderr, "Error: Valor invalido\n");
            return 1;
        }
        /* Initialize random seed for Monte Carlo */
        srand((unsigned int)time(NULL));
    }
    
    /* ===== CALCULATIONS ===== */
    
    printf("\n-------------------------------------------------\n");
    printf("Calculando...\n");
    
    /* Start timing */
    start = clock();
    
    /* Calculate mass: M = ∭ ρ(x,y,z) dV */
    if (metodo == 1) {
        masa = integrar_riemann(densidad_actual, xmin, xmax, ymin, ymax, 
                               zmin, zmax, Nx, Ny, Nz);
    } else {
        masa = integrar_montecarlo(densidad_actual, xmin, xmax, ymin, ymax, 
                                  zmin, zmax, N);
    }
    
    /* Check if mass is valid */
    if (masa <= 0.0) {
        fprintf(stderr, "Error: Masa calculada no valida (M = %g)\n", masa);
        fprintf(stderr, "Verifique los limites de integracion y la funcion de densidad.\n");
        return 1;
    }
    
    /* Calculate center of mass coordinates */
    /* x̄ = (1/M) ∭ x*ρ(x,y,z) dV */
    if (metodo == 1) {
        x_bar = integrar_riemann(f_x_rho, xmin, xmax, ymin, ymax, 
                                zmin, zmax, Nx, Ny, Nz) / masa;
    } else {
        x_bar = integrar_montecarlo(f_x_rho, xmin, xmax, ymin, ymax, 
                                   zmin, zmax, N) / masa;
    }
    
    /* ȳ = (1/M) ∭ y*ρ(x,y,z) dV */
    if (metodo == 1) {
        y_bar = integrar_riemann(f_y_rho, xmin, xmax, ymin, ymax, 
                                zmin, zmax, Nx, Ny, Nz) / masa;
    } else {
        y_bar = integrar_montecarlo(f_y_rho, xmin, xmax, ymin, ymax, 
                                   zmin, zmax, N) / masa;
    }
    
    /* z̄ = (1/M) ∭ z*ρ(x,y,z) dV */
    if (metodo == 1) {
        z_bar = integrar_riemann(f_z_rho, xmin, xmax, ymin, ymax, 
                                zmin, zmax, Nx, Ny, Nz) / masa;
    } else {
        z_bar = integrar_montecarlo(f_z_rho, xmin, xmax, ymin, ymax, 
                                   zmin, zmax, N) / masa;
    }
    
    /* End timing */
    end = clock();
    tiempo = (double)(end - start) / CLOCKS_PER_SEC;
    
    /* ===== OUTPUT RESULTS ===== */
    
    printf("-------------------------------------------------\n\n");
    printf("RESULTADOS:\n");
    printf("  Masa total (M):         %g\n", masa);
    printf("  Centro de masa (x̄):     %g\n", x_bar);
    printf("  Centro de masa (ȳ):     %g\n", y_bar);
    printf("  Centro de masa (z̄):     %g\n", z_bar);
    printf("  Tiempo de calculo:      %.6f segundos\n", tiempo);
    printf("\n");
    
    /* ===== SAVE TO CSV FILE ===== */
    
    FILE *archivo = fopen("resultados/resultados.csv", "a");
    if (archivo == NULL) {
        fprintf(stderr, "Advertencia: No se pudo abrir archivo de resultados\n");
        fprintf(stderr, "Asegurese de que la carpeta 'resultados/' existe\n");
    } else {
        /* Check if file is empty to write header */
        fseek(archivo, 0, SEEK_END);
        long tamanio = ftell(archivo);
        
        if (tamanio == 0) {
            /* Write CSV header */
            fprintf(archivo, "Metodo,Densidad,Nx,Ny,Nz,N,M,x_bar,y_bar,z_bar,Tiempo\n");
        }
        
        /* Write data row */
        const char* metodo_str = (metodo == 1) ? "Riemann" : "MonteCarlo";
        const char* densidad_str;
        switch(tipo_densidad) {
            case 1: densidad_str = "Constante"; break;
            case 2: densidad_str = "Lineal"; break;
            case 3: densidad_str = "Gaussiana"; break;
            default: densidad_str = "Desconocida";
        }
        
        if (metodo == 1) {
            fprintf(archivo, "%s,%s,%d,%d,%d,%d,%g,%g,%g,%g,%.6f\n",
                   metodo_str, densidad_str, Nx, Ny, Nz, 0,
                   masa, x_bar, y_bar, z_bar, tiempo);
        } else {
            fprintf(archivo, "%s,%s,%d,%d,%d,%d,%g,%g,%g,%g,%.6f\n",
                   metodo_str, densidad_str, 0, 0, 0, N,
                   masa, x_bar, y_bar, z_bar, tiempo);
        }
        
        fclose(archivo);
        printf("Resultados guardados en 'resultados/resultados.csv'\n\n");
    }
    
    return 0;
}
